#!/bin/bash
python -u myAI.py

# FOR c++
# g++ myAI.cpp
# ./a.out