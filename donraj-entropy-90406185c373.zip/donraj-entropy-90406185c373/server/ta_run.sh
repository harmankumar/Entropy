# ta_run.sh: This file is used by the system and not supposed to be run manually
# >&2 echo $(pwd)
python -u ../server/TA-AI.py
